def register_task(self, task_tag: str, predicates=None, actions=None, verifier=None):
    # ... existing registration logic ...

    # === NEW: Automatic transfer attempt ===
    known_tasks = list(self.rule_learner.learned_rules.keys())
    if known_tasks:
        # For each known task, attempt analogical alignment
        for known_task in known_tasks:
            if known_task == task_tag:
                continue
            try:
                # Build concept HVs for both domains
                known_hvs = self._get_concept_hvs_for_task(known_task)
                new_hvs = self._get_concept_hvs_for_task(task_tag)
                if known_hvs and new_hvs:
                    mappings = self.analogy_engine.auto_discover_abstractions(
                        known_task, task_tag, known_hvs, new_hvs
                    )
                    if mappings:
                        # Transfer rules
                        transferred = self._transfer_rules(known_task, task_tag)
                        logger.info("[TRANSFER] %d rules transferred from %s → %s",
                                   transferred, known_task, task_tag)
            except Exception as e:
                logger.debug("[TRANSFER] Auto-transfer failed: %s", e)