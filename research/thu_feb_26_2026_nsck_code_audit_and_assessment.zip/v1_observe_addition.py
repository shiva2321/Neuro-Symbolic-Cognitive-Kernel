# After updating rule confidence:
if rule.support % 10 == 0:  # Every 10 observations
    rule.confidence_history.append(rule.confidence)
    if len(rule.confidence_history) > 200:
        rule.confidence_history.pop(0)  # Sliding window