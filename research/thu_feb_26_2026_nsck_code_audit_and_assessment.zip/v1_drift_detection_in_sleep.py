# === NEW STEP in sleep(): Drift detection ===
drifted_rules = []
for rule in self.rule_learner.get_rules(task):
    if len(rule.confidence_history) >= 20:
        recent = rule.confidence_history[-10:]
        old = rule.confidence_history[-20:-10]
        recent_mean = sum(recent) / len(recent)
        old_mean = sum(old) / len(old)
        if old_mean > 0.3 and recent_mean < old_mean * 0.5:
            drifted_rules.append(rule)
            rule.tenure = "drifting"
            logger.info("[DRIFT] Rule %s confidence dropped %.0f%%: %.2f → %.2f",
                       rule.id, (1 - recent_mean/old_mean)*100, old_mean, recent_mean)