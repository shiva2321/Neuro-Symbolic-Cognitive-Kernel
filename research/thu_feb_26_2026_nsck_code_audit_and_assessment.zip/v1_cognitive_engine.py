def decide(
    self,
    state: Dict[str, Any],     # ← raw, untyped, modality-specific
    task_tag: str,
    ...
) -> CognitiveState:
    verifier = self.verifiers.get(task_tag, GroundingVerifier())
    active_preds = verifier.get_active_predicates(state, context=task_tag)
    situation_hv = self.episodic_memory.create_situation_hv(state, task_tag, active_preds)