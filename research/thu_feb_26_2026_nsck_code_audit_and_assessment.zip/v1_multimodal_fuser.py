"""Fuse multiple PerceptPackets into one coherent percept."""
from typing import List
from python.core.types.percept_packet import PerceptPacket
import python.core.vsa.hypervec_shim as hv


class MultimodalFuser:
    """Combine percepts from different modalities into one PerceptPacket.

    Uses VSA bundle for situation_hv fusion (mathematically: the bundled
    vector is maximally similar to all components — exactly what we want).
    """

    def fuse(self, packets: List[PerceptPacket]) -> PerceptPacket:
        if len(packets) == 1:
            return packets[0]

        # 1. Bundle situation HVs
        fused_hv = packets[0].situation_hv
        for p in packets[1:]:
            fused_hv = fused_hv.bundle(p.situation_hv)

        # 2. Merge entity HVs (same key → bundle; new key → add)
        merged_entities = {}
        for p in packets:
            for name, entity_hv in p.entity_hvs.items():
                if name in merged_entities:
                    merged_entities[name] = merged_entities[name].bundle(entity_hv)
                else:
                    merged_entities[name] = entity_hv

        # 3. Collect all relations
        all_relations = []
        for p in packets:
            all_relations.extend(p.relation_hvs)

        # 4. Union predicates
        all_preds = frozenset().union(*(p.active_predicates for p in packets))

        # 5. Weighted average confidence
        avg_conf = sum(p.confidence for p in packets) / len(packets)

        # 6. Merge raw_state dicts
        merged_raw = {}
        for p in packets:
            if p.raw_state:
                merged_raw.update(p.raw_state)

        return PerceptPacket(
            modality="multimodal",
            timestamp=max(p.timestamp for p in packets),
            situation_hv=fused_hv,
            entity_hvs=merged_entities,
            relation_hvs=all_relations,
            active_predicates=all_preds,
            confidence=avg_conf,
            raw_state=merged_raw if merged_raw else None,
            adapter_name="MultimodalFuser",
            adapter_trace={"sources": [p.adapter_name for p in packets],
                          "n_fused": len(packets)},
        )