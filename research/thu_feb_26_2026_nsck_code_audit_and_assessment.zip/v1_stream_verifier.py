class StreamVerifier(GroundingVerifier):
    """Auto-generates predicates from temporal features."""

    def __init__(self, base_verifier=None):
        super().__init__()
        self.base = base_verifier

    def get_active_predicates(self, state, context=None):
        preds = []
        if self.base:
            preds.extend(self.base.get_active_predicates(state, context))

        # Auto-generate from temporal features
        for key, val in state.items():
            if key.endswith("_is_rising") and val:
                preds.append(f"RISING_{key.replace('_is_rising', '').upper()}")
            elif key.endswith("_is_falling") and val:
                preds.append(f"FALLING_{key.replace('_is_falling', '').upper()}")
            elif key.endswith("_anomaly") and val:
                preds.append(f"ANOMALY_{key.replace('_anomaly', '').upper()}")
        return preds