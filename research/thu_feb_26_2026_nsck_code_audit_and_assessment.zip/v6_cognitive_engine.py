def register_task(self, task_tag, verifier=None, causal_graph=None):
    if verifier:
        self.verifiers[task_tag] = verifier
        self.rule_learner.register_verifier(task_tag, verifier)
    if causal_graph is None:
        causal_graph = CausalGraph()
    self.causal_graphs[task_tag] = causal_graph
    self.causal_reasoners[task_tag] = CausalReasoner(causal_graph)
    # ... TaskBrain setup ...
    logger.info("Registered task '%s'", task_tag)