# 1. Rule learning observation
self.rule_learner.observe(state, action, reward, task_tag, outcome)

# 2. Episode recording (store the raw experience)
self.episodic_memory.record(episode)

# 3. Self-model update (calibration)
self.self_model.update(...)

# 4. Periodic rule induction (every 50 episodes)
if self.stats["episodes_recorded"] % 50 == 0:
    self.rule_learner.induce_rules(task_tag)

# 5. Causal discovery (if next_state provided)
if next_state:
    self.causal_discovery.observe(...)