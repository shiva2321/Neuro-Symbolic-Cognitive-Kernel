def add_transferred_rule(self, task_tag, condition, consequence, source_task, source_confidence):
    """Inject a rule from analogical transfer (lower initial confidence)."""
    rule = Rule(
        id=f"transfer_{source_task}_{len(self.learned_rules.get(task_tag, []))}",
        condition=frozenset(condition),
        consequence=consequence,
        confidence=source_confidence,
        success_rate=0.5,  # Unknown in new domain
        support=0,
        tenure="bootstrap",
        scope=self._determine_scope(frozenset(condition)),
        source=f"transfer:{source_task}",
    )
    self.learned_rules.setdefault(task_tag, []).append(rule)