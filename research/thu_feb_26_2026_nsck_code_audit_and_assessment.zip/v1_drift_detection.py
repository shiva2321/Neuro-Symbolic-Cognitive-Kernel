def detect_drift(self, task_tag: str, window_size: int = 100) -> List[str]:
    """Find rules whose success rate has dropped significantly recently."""
    drifted = []
    for rule in self.rule_learner.get_rules(task_tag):
        if len(rule.confidence_trajectory) >= window_size:
            recent = rule.confidence_trajectory[-window_size:]
            old = rule.confidence_trajectory[:-window_size]
            if mean(recent) < mean(old) * 0.7:  # 30% drop
                drifted.append(rule)
                rule.status = "drifting"
    return drifted