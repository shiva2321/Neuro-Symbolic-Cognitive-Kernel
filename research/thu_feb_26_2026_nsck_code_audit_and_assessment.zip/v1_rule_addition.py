@dataclass
class Rule:
    # ... existing fields ...
    confidence_history: List[float] = field(default_factory=list)  # NEW
    last_fired: float = 0.0                                        # NEW
    fire_count: int = 0                                            # NEW