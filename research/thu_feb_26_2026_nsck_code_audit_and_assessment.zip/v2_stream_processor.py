"""Converts continuous temporal streams into PerceptPackets."""
import time
from collections import deque
from typing import Any, Dict, Optional, List
from python.core.types.percept_packet import PerceptPacket
from python.core.types.modality_adapter import ModalityAdapter


class StreamProcessor:
    """Accumulates temporal data points and emits PerceptPackets when ready."""

    def __init__(self, window_size: int = 50, emit_every: int = 1):
        self.window_size = window_size
        self.emit_every = emit_every
        self.channels: Dict[str, deque] = {}
        self._ingest_count = 0

    def ingest(self, channel: str, value: Any, timestamp: Optional[float] = None):
        """Add one data point to a channel."""
        ts = timestamp or time.time()
        if channel not in self.channels:
            self.channels[channel] = deque(maxlen=self.window_size)
        self.channels[channel].append((ts, value))
        self._ingest_count += 1

    def ready(self) -> bool:
        """Check if we have enough data to emit."""
        return (self._ingest_count >= self.emit_every and
                any(len(ch) >= 2 for ch in self.channels.values()))

    def emit(self, adapter: ModalityAdapter, task_tag: str) -> Optional[PerceptPacket]:
        """Extract temporal features and convert via adapter."""
        if not self.ready():
            return None
        features = self._extract_features()
        self._ingest_count = 0
        return adapter.encode(features, task_tag)

    def _extract_features(self) -> Dict[str, Any]:
        """Compute temporal predicates from buffered data."""
        features = {}
        for channel, values in self.channels.items():
            numeric_vals = [v for _, v in values if isinstance(v, (int, float))]
            if not numeric_vals:
                features[channel] = values[-1][1] if values else None
                continue

            features[f"{channel}"] = numeric_vals[-1]
            features[f"{channel}_mean"] = sum(numeric_vals) / len(numeric_vals)
            features[f"{channel}_min"] = min(numeric_vals)
            features[f"{channel}_max"] = max(numeric_vals)

            if len(numeric_vals) >= 2:
                trend = numeric_vals[-1] - numeric_vals[0]
                features[f"{channel}_trend"] = trend
                features[f"{channel}_is_rising"] = all(
                    numeric_vals[i] <= numeric_vals[i+1] for i in range(len(numeric_vals)-1)
                )
                features[f"{channel}_is_falling"] = all(
                    numeric_vals[i] >= numeric_vals[i+1] for i in range(len(numeric_vals)-1)
                )
                # Rate of change
                dt = (values[-1][0] - values[0][0]) or 1e-9
                features[f"{channel}_rate"] = trend / dt

            # Anomaly: current value > 2 std from mean
            if len(numeric_vals) >= 5:
                mean = sum(numeric_vals) / len(numeric_vals)
                var = sum((x - mean)**2 for x in numeric_vals) / len(numeric_vals)
                std = var ** 0.5
                if std > 0 and abs(numeric_vals[-1] - mean) > 2 * std:
                    features[f"{channel}_anomaly"] = True

        return features