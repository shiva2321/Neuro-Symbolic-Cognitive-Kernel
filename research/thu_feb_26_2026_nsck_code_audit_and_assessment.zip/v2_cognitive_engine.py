def decide(self, state: Dict[str, Any], task_tag: str, ...):
    # 1. Symbol grounding (PERCEPTION — happens inside decide)
    verifier = self.verifiers.get(task_tag, GroundingVerifier())
    active_preds = verifier.get_active_predicates(state, context=task_tag)

    # 2. Situation hypervector (ENCODING — happens inside decide)
    situation_hv = self.episodic_memory.create_situation_hv(state, task_tag, active_preds)

    # 3. Curiosity check (COGNITION — starts here)
    explore_decision = self.curiosity.should_explore(situation_hv, task_tag, confidence)