def register_task(self, task_tag, verifier=None, causal_graph=None, adapter=None):
    # ... ALL existing logic stays exactly as-is ...

    # === NEW: Automatic transfer attempt ===
    known_tasks = [t for t in self.rule_learner.learned_rules if t != task_tag
                   and len(self.rule_learner.learned_rules[t]) > 0]

    if known_tasks and self.config.enable_auto_transfer:
        transferred_total = 0
        for source_task in known_tasks:
            try:
                source_hvs = self._collect_concept_hvs_for_task(source_task)
                target_hvs = self._collect_concept_hvs_for_task(task_tag)
                if source_hvs and target_hvs:
                    mappings = self.analogy_engine.auto_discover_abstractions(
                        source_task, task_tag, source_hvs, target_hvs,
                        similarity_threshold=0.52,
                    )
                    if mappings:
                        # Transfer rules via analogy
                        source_rules = self.rule_learner.get_rules(source_task)
                        for rule in source_rules:
                            new_cond, new_act = self.analogy_engine.transfer_rule(
                                rule.condition, rule.consequence, source_task, task_tag
                            )
                            if new_cond != rule.condition:  # Actually mapped something
                                self.rule_learner.add_transferred_rule(
                                    task_tag, new_cond, new_act,
                                    source_task=source_task,
                                    source_confidence=rule.confidence * 0.7,
                                )
                                transferred_total += 1
            except Exception as e:
                logger.debug("[TRANSFER] Auto-transfer %s→%s failed: %s", source_task, task_tag, e)

        if transferred_total:
            logger.info("[TRANSFER] Auto-transferred %d rules to new task '%s'", transferred_total, task_tag)
            self.stats.setdefault("auto_transfers", 0)
            self.stats["auto_transfers"] += transferred_total