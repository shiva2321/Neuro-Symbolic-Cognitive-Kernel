def test_sleep_builds_prototypes():
    engine = _make_engine()
    # Add concepts with is_a relations to semantic memory
    for animal in ["Dog", "Cat", "Bird"]:
        engine.semantic_memory.add_concept(animal, {})
    engine.semantic_memory.add_concept("Animal", {})
    for a in ["Dog", "Cat", "Bird"]:
        engine.semantic_memory.add_relation(a, "is_a", "Animal")
    _train_engine(engine, "test", "ACTION_UP", n=20)
    engine.sleep("test", epochs=1)
    assert engine.stats.get("prototypes_built", 0) >= 1

def test_sleep_does_transitive_inference():
    engine = _make_engine()
    engine.semantic_memory.add_concept("A", {})
    engine.semantic_memory.add_concept("B", {})
    engine.semantic_memory.add_concept("C", {})
    engine.semantic_memory.add_relation("A", "is_a", "B")
    engine.semantic_memory.add_relation("B", "is_a", "C")
    _train_engine(engine, "test", "ACTION_UP", n=20)
    engine.sleep("test", epochs=1)
    assert engine.semantic_memory.concept_graph.has_edge("A", "C")

def test_sleep_auto_discovers_cross_task():
    engine = _make_engine("task_a")
    engine.register_task("task_b")
    _train_engine(engine, "task_a", "ACTION_UP", n=20)
    _train_engine(engine, "task_b", "ACTION_DOWN", n=20)
    engine.sleep(epochs=1)
    assert engine.stats.get("auto_abstractions", 0) >= 0  # May find some