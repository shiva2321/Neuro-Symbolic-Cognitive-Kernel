"""Measures the 6 core substrate properties against the actual CognitiveEngine API."""
import time
from python.core.reasoning.cognitive_engine import CognitiveEngine
from python.core.reasoning.causal_reasoning import CausalGraph
from python.core.integration.config import NSCKConfig


class SubstrateBenchmarks:

    def benchmark_learning_curve(self, engine, task_tag, state_generator, n_episodes=500):
        """Measure: does success_rate increase over episodes?"""
        window = []
        results = []
        for i in range(n_episodes):
            state = state_generator()
            cs = engine.decide(state, task_tag)
            # Simple reward: did it pick the "right" action?
            reward = state_generator.evaluate(cs.chosen_action)
            engine.learn(state, cs.chosen_action, reward, task_tag,
                        outcome="success" if reward > 0 else "failure")
            window.append(reward > 0)
            if len(window) > 50:
                window.pop(0)
            if i % 50 == 49:
                results.append((i+1, sum(window)/len(window)))
        return results  # [(episode, success_rate), ...]

    def benchmark_transfer(self, engine, source_task, target_task,
                           source_gen, target_gen, n_source=200, n_target=50):
        """Train source, measure zero-shot on target, then after 10 episodes."""
        # Train on source
        for i in range(n_source):
            state = source_gen()
            cs = engine.decide(state, source_task)
            r = source_gen.evaluate(cs.chosen_action)
            engine.learn(state, cs.chosen_action, r, source_task)
        engine.sleep(source_task)

        # Register target (auto-transfer will fire via Step 3)
        engine.register_task(target_task, verifier=target_gen.verifier)

        # Zero-shot test
        zero_shot = []
        for i in range(n_target):
            state = target_gen()
            cs = engine.decide(state, target_task)
            zero_shot.append(target_gen.evaluate(cs.chosen_action) > 0)

        return {"zero_shot_rate": sum(zero_shot) / len(zero_shot)}

    def benchmark_lifelong(self, engine, task_sequence, gen_per_task, episodes_per_task=100):
        """Train A→B→C→D, measure A after D (forgetting)."""
        peak_rates = {}
        for task_tag, gen in task_sequence:
            engine.register_task(task_tag, verifier=gen.verifier)
            successes = 0
            for i in range(episodes_per_task):
                state = gen()
                cs = engine.decide(state, task_tag)
                r = gen.evaluate(cs.chosen_action)
                engine.learn(state, cs.chosen_action, r, task_tag)
                if r > 0: successes += 1
            peak_rates[task_tag] = successes / episodes_per_task
            engine.sleep(task_tag)

        # Re-test first task
        first_task, first_gen = task_sequence[0]
        retest = sum(1 for _ in range(50)
                    if first_gen.evaluate(engine.decide(first_gen(), first_task).chosen_action) > 0)
        final_rate = retest / 50

        return {
            "peak_rates": peak_rates,
            "first_task_final": final_rate,
            "forgetting_ratio": 1 - (final_rate / max(peak_rates[task_sequence[0][0]], 0.01)),
        }

    def benchmark_efficiency(self, engine, task_tag, state_gen, n=1000):
        """Measure latency per decide() call."""
        latencies = []
        for _ in range(n):
            state = state_gen()
            t0 = time.perf_counter()
            engine.decide(state, task_tag)
            latencies.append((time.perf_counter() - t0) * 1000)  # ms
        return {
            "avg_ms": sum(latencies) / len(latencies),
            "p95_ms": sorted(latencies)[int(n * 0.95)],
            "max_ms": max(latencies),
        }