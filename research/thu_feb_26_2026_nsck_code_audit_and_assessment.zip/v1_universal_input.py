def ground(self, data: Any, domain: str = "default", ...) -> hv.HyperVector:
    # Returns just an HV

def process(self, data: Any, domain: str = "default", ...) -> Dict:
    # Returns {"hv": HyperVector, "confidence": float, "trace": dict}