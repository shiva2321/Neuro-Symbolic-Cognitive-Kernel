def decide(
    self,
    percept: PerceptPacket,   # ← The ONLY input type
    task_tag: str,
    ...
) -> CognitiveState:
    # No more calling GroundingVerifier here — it already happened in the adapter
    active_preds = percept.active_predicates
    situation_hv = percept.situation_hv
    # ... proceed with coalition building, memory, reasoning