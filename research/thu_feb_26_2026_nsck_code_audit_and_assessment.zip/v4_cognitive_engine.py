def perceive_and_decide(self, sensory_input: np.ndarray, task_tag: str):
    snn_coalition = Coalition(source="SNN_PERCEPTION", content=concept_name, ...)
    return self.decide(state, task_tag, external_coalition=snn_coalition, fast_mode=True)