def decide(
    self,
    state: Dict[str, Any],     # <-- raw state dict, not a standardized PerceptPacket
    task_tag: str,
    metacognition_result: Optional[Dict] = None,
    external_coalition: Optional[Any] = None,
    fast_mode: bool = False
) -> CognitiveState:
    # 1. Symbol grounding
    verifier = self.verifiers.get(task_tag, GroundingVerifier())
    active_preds = verifier.get_active_predicates(state, context=task_tag)

    # 2. Situation hypervector
    situation_hv = self.episodic_memory.create_situation_hv(
        state, task_tag, active_preds
    )