def test_dict_adapter_produces_valid_packet():
    adapter = DictStateAdapter(verifier, episodic_memory)
    packet = adapter.encode({"head": (5,5), "food": (5,4)}, "snake")
    assert isinstance(packet, PerceptPacket)
    assert isinstance(packet.situation_hv, HyperVector)
    assert len(packet.active_predicates) > 0
    assert packet.modality == "dict"

def test_decide_accepts_percept_packet():
    engine = CognitiveEngine()
    engine.register_task("test")
    packet = PerceptPacket(modality="dict", timestamp=time.time(), situation_hv=HyperVector(42),
                           active_predicates=frozenset(["PRED_A"]))
    result = engine.decide(packet, "test")
    assert result.chosen_action is not None