@dataclass(frozen=True)
class PerceptPacket:
    """The ONE type that crosses the perception→cognition boundary.
    Every modality adapter MUST produce this. The cognitive core
    ONLY accepts this. No exceptions."""

    # --- Identity ---
    modality: str                          # "text", "numeric", "image", "audio", "dict", "stream"
    timestamp: float                       # When this percept was created

    # --- Core representations (all HVs) ---
    situation_hv: HyperVector              # Bundled summary of the entire percept
    entity_hvs: Dict[str, HyperVector]     # Named entities/concepts found
    relation_hvs: List[Tuple[str, str, str, HyperVector]]  # (subj, pred, obj, triple_hv)

    # --- Symbolic grounding ---
    active_predicates: FrozenSet[str]      # Grounded symbolic predicates
    confidence: float                      # 0.0–1.0, how reliable is this percept

    # --- Provenance (for glass-box tracing) ---
    raw_input_hash: int                    # Hash of original input (for dedup/replay)
    adapter_name: str                      # Which adapter produced this
    adapter_trace: Dict[str, Any]          # Adapter-specific debug info (not used by core)