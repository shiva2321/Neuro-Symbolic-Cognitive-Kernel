class StreamProcessor:
    """Converts continuous streams into PerceptPackets with temporal context."""

    def __init__(self, window_size: int = 50, stride: int = 1):
        self.buffer: Dict[str, deque] = {}  # channel_name → recent values
        self.window_size = window_size

    def ingest(self, channel: str, value: Any, timestamp: float):
        """Add a single data point to a channel."""
        if channel not in self.buffer:
            self.buffer[channel] = deque(maxlen=self.window_size)
        self.buffer[channel].append((timestamp, value))

    def emit_packet(self, adapter: ModalityAdapter, task_tag: str) -> Optional[PerceptPacket]:
        """When enough data accumulates, emit a PerceptPacket.

        The packet includes:
        - Current values
        - Temporal patterns (trends, periodicity, anomalies)
        - Change-point detection (something just changed)
        """
        if not self._has_enough_data():
            return None

        # Extract temporal features
        features = self._extract_temporal_features()
        # Use the adapter to convert features → PerceptPacket
        return adapter.encode(features, task_tag)

    def _extract_temporal_features(self) -> Dict[str, Any]:
        """Compute: trends, rates of change, min/max/mean, anomalies."""
        features = {}
        for channel, values in self.buffer.items():
            series = [v for _, v in values if isinstance(v, (int, float))]
            if series:
                features[f"{channel}_current"] = series[-1]
                features[f"{channel}_mean"] = sum(series) / len(series)
                features[f"{channel}_trend"] = series[-1] - series[0]
                features[f"{channel}_is_rising"] = all(series[i] <= series[i+1]
                                                       for i in range(len(series)-1))
        return features