def register_task(self, task_tag, verifier=None, causal_graph=None, adapter=None):
    # ... existing logic ...
    if adapter:
        self.adapters[task_tag] = adapter
    elif verifier:
        # Auto-create DictStateAdapter from verifier
        self.adapters[task_tag] = DictStateAdapter(verifier, self.episodic_memory)