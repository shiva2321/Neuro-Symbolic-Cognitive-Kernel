"""Adapter that wraps the existing GroundingVerifier + UniversalInput flow."""
import time
from typing import Dict, Any, Optional
from python.core.types.modality_adapter import ModalityAdapter
from python.core.types.percept_packet import PerceptPacket
from python.core.reasoning.grounding import GroundingVerifier
from python.core.memory.episodic_memory import EpisodicMemory


class DictStateAdapter(ModalityAdapter):
    """Converts Dict[str, Any] state → PerceptPacket.

    Uses the existing GroundingVerifier for predicate extraction
    and EpisodicMemory.create_situation_hv() for HV encoding.
    This is the exact same logic currently in decide() lines 458-473,
    just extracted into the adapter contract.
    """

    def __init__(self, verifier: GroundingVerifier, episodic_memory: EpisodicMemory):
        self.verifier = verifier
        self.episodic_memory = episodic_memory

    def encode(self, raw_input: Dict[str, Any], task_tag: str) -> PerceptPacket:
        active_preds = self.verifier.get_active_predicates(raw_input, context=task_tag)
        situation_hv = self.episodic_memory.create_situation_hv(raw_input, task_tag, active_preds)

        # Build entity HVs from state keys (uses UniversalInput internally)
        entity_hvs = {}
        for key, val in raw_input.items():
            if isinstance(val, (int, float)):
                entity_hvs[key] = self.episodic_memory.universal_input.ground_scalar(float(val))

        return PerceptPacket(
            modality="dict",
            timestamp=time.time(),
            situation_hv=situation_hv,
            entity_hvs=entity_hvs,
            active_predicates=frozenset(active_preds),
            confidence=1.0,
            raw_state=raw_input,
            adapter_name="DictStateAdapter",
        )