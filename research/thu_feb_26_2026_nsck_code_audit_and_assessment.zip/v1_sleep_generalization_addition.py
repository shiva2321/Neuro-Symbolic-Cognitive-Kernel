def sleep(self, task_tag=None, epochs=None):
    # ... existing steps 1-3 (replay, rules, semantic extraction) ...

    for task in tasks:
        # ... existing per-task logic ...

        # === NEW STEP 4a: Prototype building ===
        prototypes = self.semantic_memory.build_prototypes(
            category_relation="is_a", min_members=2
        )
        for category, proto_hv in prototypes.items():
            self.semantic_memory.concept_hvs[category] = proto_hv
        if prototypes:
            self.stats.setdefault("prototypes_built", 0)
            self.stats["prototypes_built"] += len(prototypes)
            logger.info("[SLEEP] Built %d prototypes", len(prototypes))

        # === NEW STEP 4b: Transitive inference ===
        new_is_a = self.semantic_memory.infer_transitive("is_a", max_hops=3)
        new_causes = self.semantic_memory.infer_transitive("causes", max_hops=2)
        if new_is_a + new_causes > 0:
            self.stats.setdefault("transitive_inferences", 0)
            self.stats["transitive_inferences"] += new_is_a + new_causes
            logger.info("[SLEEP] Inferred %d transitive edges", new_is_a + new_causes)

        # === NEW STEP 4c: Cross-task auto-discovery ===
        for other_task in tasks:
            if other_task == task:
                continue
            task_hvs = self._collect_concept_hvs_for_task(task)
            other_hvs = self._collect_concept_hvs_for_task(other_task)
            if task_hvs and other_hvs:
                discovered = self.analogy_engine.auto_discover_abstractions(
                    task, other_task, task_hvs, other_hvs
                )
                if discovered:
                    self.stats.setdefault("auto_abstractions", 0)
                    self.stats["auto_abstractions"] += len(discovered)
                    logger.info("[SLEEP] Auto-discovered %d cross-task abstractions: %s↔%s",
                               len(discovered), task, other_task)

        # 4. Refresh planner operators (existing)
        graph = self.causal_graphs.get(task)
        if graph and graph.all_links:
            self.planner.learn_operators_from_graph(graph, context=task)

    # ... existing homeostasis, stigmergy ...