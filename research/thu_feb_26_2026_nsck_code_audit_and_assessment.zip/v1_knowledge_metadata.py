@dataclass
class KnowledgeMetadata:
    """Attached to every rule, relation, concept, episode."""
    created_at: float
    last_accessed: float
    access_count: int
    utility_score: float        # How much did this knowledge improve decisions?
    confidence_trajectory: List[float]  # Track confidence over time (detect drift)
    source_provenance: str      # Where did this come from?
    version: int                # Incremented on update