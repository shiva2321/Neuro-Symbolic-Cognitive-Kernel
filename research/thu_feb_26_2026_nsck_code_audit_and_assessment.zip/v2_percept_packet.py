"""The universal internal currency type for the perception→cognition boundary."""
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, FrozenSet, Any, Optional
import time
import python.core.vsa.hypervec_shim as hv


@dataclass(frozen=True)
class PerceptPacket:
    """Every modality adapter MUST produce this. CognitiveEngine ONLY accepts this."""

    modality: str                                                    # "text", "numeric", "dict", "snn", "multimodal"
    timestamp: float                                                 # time.time()
    situation_hv: hv.HyperVector                                     # Bundled summary
    entity_hvs: Dict[str, hv.HyperVector] = field(default_factory=dict)   # Named concept → HV
    relation_hvs: List[Tuple[str, str, str, hv.HyperVector]] = field(default_factory=list)  # (subj, pred, obj, triple_hv)
    active_predicates: FrozenSet[str] = field(default_factory=frozenset)   # Grounded symbolic predicates
    confidence: float = 1.0                                          # How reliable
    raw_state: Optional[Dict[str, Any]] = None                       # Original state dict (for backward compat / episodic storage)
    adapter_name: str = ""                                           # Which adapter produced this
    adapter_trace: Dict[str, Any] = field(default_factory=dict)      # Debug info