def prune_unused_rules(self, rule_learner, task_tag, min_fires=2, max_age_episodes=500):
    """Remove rules that have never been useful."""
    current_time = time.time()
    pruned = 0
    rules = rule_learner.learned_rules.get(task_tag, [])
    to_keep = []
    for rule in rules:
        age_ok = rule.fire_count >= min_fires or rule.support < max_age_episodes
        if age_ok or rule.tenure == "tenured":
            to_keep.append(rule)
        else:
            pruned += 1
    rule_learner.learned_rules[task_tag] = to_keep
    return pruned