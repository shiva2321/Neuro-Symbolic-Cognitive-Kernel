def decide(
    self,
    state_or_percept,  # Union[Dict[str, Any], PerceptPacket]
    task_tag: str,
    metacognition_result: Optional[Dict] = None,
    external_coalition: Optional[Any] = None,
    fast_mode: bool = False,
) -> CognitiveState:
    # Backward compatibility: auto-wrap raw dicts
    if isinstance(state_or_percept, dict):
        adapter = self._get_adapter(task_tag)
        percept = adapter.encode(state_or_percept, task_tag)
    else:
        percept = state_or_percept  # Already a PerceptPacket

    # From here on, only use percept — never raw state
    active_preds = percept.active_predicates
    situation_hv = percept.situation_hv
    state = percept.raw_state or {}  # For Q-value state_key compat

    # ... rest of decide() unchanged from line 473 onward ...