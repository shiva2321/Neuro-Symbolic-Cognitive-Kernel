def __init__(self):
    self.target_edge_density = 0.1
    self.max_contradiction_rate = 0.2
    self.max_staleness_days = 30.0
    self.target_activation_entropy = 2.0