def forget_low_utility(self, memory, min_utility: float = 0.01):
    """Remove knowledge that hasn't been useful."""
    for concept in list(memory.concept_hvs.keys()):
        meta = memory.get_metadata(concept)
        if meta.utility_score < min_utility and meta.access_count < 3:
            memory.remove_concept(concept)