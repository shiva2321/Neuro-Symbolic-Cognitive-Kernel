def decide_multimodal(self, inputs: List, task_tag: str, **kwargs) -> CognitiveState:
    """Accept multiple simultaneous inputs, fuse, then decide.

    inputs: list of (raw_input, adapter_or_modality_name) pairs
    """
    packets = []
    for raw, adapter_key in inputs:
        adapter = self.adapters.get(adapter_key) or self.adapters.get(task_tag)
        packets.append(adapter.encode(raw, task_tag))
    fused = self.multimodal_fuser.fuse(packets)
    return self.decide(fused, task_tag, **kwargs)