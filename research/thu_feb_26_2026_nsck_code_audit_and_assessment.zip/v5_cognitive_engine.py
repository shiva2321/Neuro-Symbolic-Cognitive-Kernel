for epoch in range(n_epochs):
    # 1. Replay episodes → rule_learner.observe()
    # 2. Induce rules → rule_learner.induce_rules()

# 3. Semantic extraction → _consolidate_semantic()
# 4. Planner refresh → planner.learn_operators_from_graph()

# Post: homeostasis.regulate() + stigmergy evaporation