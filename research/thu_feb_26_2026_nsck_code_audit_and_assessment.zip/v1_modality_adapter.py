"""Abstract base class for modality adapters."""
from abc import ABC, abstractmethod
from typing import Any
from python.core.types.percept_packet import PerceptPacket


class ModalityAdapter(ABC):
    """Every input modality must implement this single method."""

    @abstractmethod
    def encode(self, raw_input: Any, task_tag: str) -> PerceptPacket:
        """Convert raw modality-specific input into a PerceptPacket."""
        ...