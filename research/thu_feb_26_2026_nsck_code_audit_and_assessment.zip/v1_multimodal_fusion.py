class MultimodalFuser:
    """Fuse multiple PerceptPackets into one coherent percept."""

    def fuse(self, packets: List[PerceptPacket]) -> PerceptPacket:
        # 1. Bundle all situation HVs
        fused_situation = packets[0].situation_hv
        for p in packets[1:]:
            fused_situation = fused_situation.bundle(p.situation_hv)

        # 2. Merge entity HVs (same name → bundle, new name → add)
        merged_entities = {}
        for p in packets:
            for name, hv in p.entity_hvs.items():
                if name in merged_entities:
                    merged_entities[name] = merged_entities[name].bundle(hv)
                else:
                    merged_entities[name] = hv

        # 3. Union all relations
        all_relations = []
        for p in packets:
            all_relations.extend(p.relation_hvs)

        # 4. Union all predicates
        all_preds = frozenset().union(*(p.active_predicates for p in packets))

        # 5. Weighted confidence
        avg_confidence = sum(p.confidence for p in packets) / len(packets)

        return PerceptPacket(
            modality="multimodal",
            timestamp=max(p.timestamp for p in packets),
            situation_hv=fused_situation,
            entity_hvs=merged_entities,
            relation_hvs=all_relations,
            active_predicates=all_preds,
            confidence=avg_confidence,
            raw_input_hash=hash(tuple(p.raw_input_hash for p in packets)),
            adapter_name="MultimodalFuser",
            adapter_trace={"sources": [p.adapter_name for p in packets]},
        )