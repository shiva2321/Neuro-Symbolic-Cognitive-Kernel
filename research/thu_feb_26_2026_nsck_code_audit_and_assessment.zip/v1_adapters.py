class ModalityAdapter(ABC):
    """Every input type must implement this."""
    @abstractmethod
    def encode(self, raw_input: Any, task_tag: str) -> PerceptPacket: ...

class NumericAdapter(ModalityAdapter):
    def encode(self, raw_input: Union[float, List[float]], task_tag: str) -> PerceptPacket: ...

class TextAdapter(ModalityAdapter):
    def encode(self, raw_input: str, task_tag: str) -> PerceptPacket: ...

class DictStateAdapter(ModalityAdapter):
    """Wraps the existing GroundingVerifier + UniversalInput logic."""
    def encode(self, raw_input: Dict, task_tag: str) -> PerceptPacket: ...

class ImageFeatureAdapter(ModalityAdapter):
    def encode(self, raw_input: np.ndarray, task_tag: str) -> PerceptPacket: ...