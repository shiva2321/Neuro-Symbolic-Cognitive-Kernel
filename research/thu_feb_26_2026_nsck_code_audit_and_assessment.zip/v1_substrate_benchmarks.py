class SubstrateBenchmarks:
    """Measures the 6 core substrate properties."""

    def benchmark_learning_curve(self, engine, task, n_episodes=500):
        """Does performance improve with experience?
        Returns: list of (episode_num, success_rate) pairs."""

    def benchmark_generalization(self, engine, train_task, test_variants, n_train=200):
        """After training on task A, test on variants A', A'', A'''.
        Returns: {variant: success_rate}"""

    def benchmark_transfer(self, engine, source_task, target_task, n_source=200):
        """Train on source, measure zero-shot performance on target.
        Returns: (zero_shot_rate, after_10_episodes_rate, baseline_rate)"""

    def benchmark_lifelong(self, engine, task_sequence, episodes_per_task=100):
        """Train on tasks A, B, C, D. Measure A performance after learning D.
        Returns: {task: (peak_rate, final_rate, forgetting_ratio)}"""

    def benchmark_multimodal(self, engine, paired_inputs, n=100):
        """Feed text+numeric simultaneously vs separately.
        Returns: (fused_accuracy, text_only_accuracy, numeric_only_accuracy)"""

    def benchmark_efficiency(self, engine, task, n=1000):
        """Measure decision latency, memory footprint, episodes/second.
        Returns: {avg_latency_ms, peak_memory_mb, throughput_eps}"""