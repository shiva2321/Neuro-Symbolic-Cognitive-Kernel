def sleep(self, task_tag=None, epochs=None):
    # ... existing replay + rule induction ...

    for task in tasks:
        # === EXISTING ===
        # 1. Replay episodes → re-observe for rules
        # 2. Induce rules
        # 3. Semantic extraction (predicate co-occurrence)

        # === NEW: Generalization stage ===

        # 4. Build/refresh prototypes for all categories
        prototypes = self.semantic_memory.build_prototypes(min_members=2)
        for category, proto_hv in prototypes.items():
            self.semantic_memory.concept_hvs[category] = proto_hv  # Update stored prototype

        # 5. Transitive inference (close is_a, causes, part_of chains)
        new_edges = self.semantic_memory.infer_transitive("is_a", max_hops=3)
        new_edges += self.semantic_memory.infer_transitive("causes", max_hops=2)

        # 6. Schema extraction from episodic patterns
        schemas = self._extract_episode_schemas(task)
        for schema in schemas:
            self._store_schema(schema)

        # 7. Cross-task auto-discovery (if multiple tasks known)
        for other_task in tasks:
            if other_task != task:
                self.analogy_engine.auto_discover_abstractions(
                    task, other_task,
                    self._get_concept_hvs_for_task(task),
                    self._get_concept_hvs_for_task(other_task)
                )

    # === Homeostasis (already exists) ===
    self.homeostasis.regulate(self.semantic_memory)