def _collect_concept_hvs_for_task(self, task_tag: str) -> Dict[str, hv.HyperVector]:
    """Collect all concept HVs relevant to a task from semantic memory + rules."""
    hvs = {}
    # From rule learner predicates
    for rule in self.rule_learner.get_rules(task_tag):
        for pred in rule.condition:
            if pred not in hvs:
                hvs[pred] = self.get_concept_hv(pred)
        if rule.consequence not in hvs:
            hvs[rule.consequence] = self.get_concept_hv(rule.consequence)
    # From causal graph nodes
    graph = self.causal_graphs.get(task_tag)
    if graph:
        for link in graph.all_links:
            for name in (link.cause, link.effect):
                if name not in hvs:
                    hvs[name] = self.get_concept_hv(name)
    return hvs